***** QEA22CSDQE007_Team3_IdentifyCourses *****

Setup required in Eclipse:
1. Open QEA22CSDQE007_Team3_IdentifyCourses project in Eclipse and wait until the Eclipse completes the Build.
2. Setup values in Config.properties and its path will be setup dynamically. 
3. Setup SystemInfo in ExtentReportManager.java file Line 25 & 26.
4. *Ignore if OS is Windows* Comment lines below For Windows comment if you are using Linux or Mac and uncomment line below For Linux or Mac comment and vice-versa in following java files :
	a. ExtentReportManager : (comment) Line 20 --- (uncomment) Line 18
	b. PageBaseClass : (comment) Line 90 & 96 --- (uncomment) Line 88 & 94
	c. BaseTestClass : (comment) Line 39 --- (uncomment) Line 37
5. Run the testng.xml file as TestNG Suite. (testng.xml->Run As->TestNg Suite)
6. Refresh Project to see latest Test Report and ScreenShot.
7. Test Report is saved in test-reports folder. 
8. Error ScreenShot is saved in ScreenShots folder.

Problem Statement : Identify Courses

Search and display all web development courses :

1. Should be for beginners level.
2. Courses offered in English language.
3. Display first two courses with name, total learning hours and rating.
(Suggested Site: coursera.org however  you are free to choose any other legitimate  site)

Detailed Description: Hackathon Ideas :

1. Search for web development courses for Beginners level & English Language and extract the course names, total learning hours & rating for first 2 courses.
2. Look for Language Learning; Extract all the languages and different levels with its total count & display them.
3. In Home page, go to "For Enterprise"; Look into Courses for Campus under Product; Fill the  "Ready to transform" form with any one input invalid (example: email); Capture the error message & display.
(Suggested Site: coursera.org however  you are free to choose any other legitimate site)

Key Automation Scope :

1.Handling different browser windows, search option.
2.Extract multiple drop down list items & store in collections.
3.Navigating back to home page.
4.Filling form (in different objects in web page).
5.Capture warning message.
6.Scrolling down in web page.

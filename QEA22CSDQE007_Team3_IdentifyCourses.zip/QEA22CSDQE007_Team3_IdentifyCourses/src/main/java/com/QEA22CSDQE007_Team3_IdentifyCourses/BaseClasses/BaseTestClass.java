package com.QEA22CSDQE007_Team3_IdentifyCourses.BaseClasses;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;

import com.QEA22CSDQE007_Team3_IdentifyCourses.Utils.ExtentReportManager;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseTestClass
{
	public WebDriver driver;
	public static Properties property;
	public ExtentReports report = ExtentReportManager.getReportInstance();
	public ExtentTest logger;
	
	/****************************** Invoke Browser ******************************/	
	public void invokeBrowser()
	{	
		property = new Properties();
		try {
			//Loading the properties
			//For Linux or Mac
			//property.load(new FileInputStream(System.getProperty("user.dir") + "/src/test/resources/objectRepository/Config.properties"));
			//For Windows
			property.load(new FileInputStream(System.getProperty("user.dir") + "//src//test//resources//objectRepository//Config.properties"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		String browser = property.getProperty("browserName");
		
		try 
		{
			System.out.println("\nLaunching " + browser + " successfully.\n");
			
			//Setting up Chrome Driver
			if(browser.equalsIgnoreCase("Chrome"))
			{
				//Create ChromeOptions instance as options
				ChromeOptions options = new ChromeOptions();
				WebDriverManager.chromedriver().setup();

				//Create ChromeDriver instance as driver
				driver = new ChromeDriver(options);
			}

			//Setting up Firefox Driver
			else if(browser.equalsIgnoreCase("Firefox"))
			{
				//Create FirefoxOptions instance as options
				FirefoxOptions options = new FirefoxOptions();
				WebDriverManager.firefoxdriver().setup();

				//Create FirefoxDriver instance as driver
				driver = new FirefoxDriver(options);
			}

			//Setting up Edge Driver
			else
			{
				//Create EdgeOptions instance as options
				EdgeOptions options = new EdgeOptions();
				WebDriverManager.edgedriver().setup();

				//Create EdgeDriver instance as driver
				driver = new EdgeDriver(options);
			}
		} 
		catch(Exception e) 
		{
			//reportFail(e.getMessage());
			System.out.println(e.getMessage());
		}
		
		//Add implicitly wait to the driver                                                                                                                                     
		driver.manage().timeouts().implicitlyWait(180, TimeUnit.SECONDS);
		
		//Maximize the Browser window
		driver.manage().window().maximize();
		
		//Wait for the page to load
		driver.manage().timeouts().pageLoadTimeout(180, TimeUnit.SECONDS);
	}
	
	@AfterMethod
	public void flushReports()
	{
		//Flush the report
		report.flush();
		
		//Close the driver
		driver.close();
	}
	
	@AfterTest
	public void automationCompleted()
	{
		System.out.println("\nTestCase completed successfully.");
	}
}
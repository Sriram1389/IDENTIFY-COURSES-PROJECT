package com.QEA22CSDQE007_Team3_IdentifyCourses.BaseClasses;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.QEA22CSDQE007_Team3_IdentifyCourses.PageClasses.LandingPage;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class TopMenuClass extends PageBaseClass
{
	public TopMenuClass(WebDriver driver, ExtentTest logger)
	{
		super(driver, logger);
	}
	
	@FindBy(xpath="//img[@alt='Coursera']")
	public WebElement backToHome;
	
	//Navigate to Home page function
	public LandingPage navigateToHome()
	{
		logger.log(Status.INFO, "Navigate to Home page.");
		backToHome.click();
		logger.log(Status.PASS, "Navigated to Home page successfully.");
		System.out.println("Navigated to Home page successfully.");
		
		LandingPage landingPage = new LandingPage(driver, logger); 
		PageFactory.initElements(driver, landingPage);
		return landingPage;
	}
}
package com.QEA22CSDQE007_Team3_IdentifyCourses.BaseClasses;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.QEA22CSDQE007_Team3_IdentifyCourses.PageClasses.LandingPage;
import com.QEA22CSDQE007_Team3_IdentifyCourses.Utils.DateUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class PageBaseClass extends BaseTestClass
{
	public ExtentTest logger;
	public static WebDriverWait wait;
	
	public PageBaseClass(WebDriver driver, ExtentTest logger)
	{
		this.driver = driver;
		this.logger = logger;
	}
	
	/****************************** Open Application ******************************/
	public LandingPage openApplication()
	{
		String websiteURL = property.getProperty("websiteURL");
		logger.log(Status.INFO, "Opening the WebSite.");
		driver.get(websiteURL);
		logger.log(Status.PASS, "Successfully opened the URL : " + websiteURL);
		System.out.println("\nSuccessfully opened the URL :" + websiteURL + "\n");
		
		LandingPage landingPage = new LandingPage(driver, logger);
		PageFactory.initElements(driver, landingPage);
		return landingPage;
	}
	
	/****************************** Wait for the Element *****************************/
	public void wait(int sec, By locator) 
	{
		wait = new WebDriverWait(driver, sec);
		wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	}
	
	/****************************** Wait for the Element *****************************/
	public void waitElement(int sec, WebElement element) 
	{
		wait = new WebDriverWait(driver, sec);
		wait.until(ExpectedConditions.visibilityOf(element));
	}
	
	/****************************** Wait for the List Element *****************************/
	public void waitList(int sec, List<WebElement> element) 
	{
		wait = new WebDriverWait(driver, sec);
		wait.until(ExpectedConditions.visibilityOfAllElements(element));
	}
	
	/****************************** Reporting Functions ******************************/	
	public void reportFail(String reportString)
	{
		logger.log(Status.FAIL, reportString);
		takeScreenShotOnFailure();
	}
	
	public void reportPass(String reportString)
	{
		logger.log(Status.PASS, reportString);
	}
	
	/****************************** Capture ScreenShot ******************************/	
	public void takeScreenShotOnFailure()
	{
		TakesScreenshot takeScreenShot = (TakesScreenshot)driver;
		File sourceFile = takeScreenShot.getScreenshotAs(OutputType.FILE);
		//For Linux or Mac
		//File destFile = new File(System.getProperty("user.dir") + "/ScreenShots/" + DateUtils.getTimeStamp() + ".png");
		//For Windows
		File destFile = new File(System.getProperty("user.dir") + "//ScreenShots//" + DateUtils.getTimeStamp() + ".png");
		try {
			FileUtils.copyFile(sourceFile, destFile);
			//For Linux or Mac
			//logger.addScreenCaptureFromPath(System.getProperty("user.dir") + "/ScreenShots/" + DateUtils.getTimeStamp() + ".png");
			//For Windows
			logger.addScreenCaptureFromPath(System.getProperty("user.dir") + "//ScreenShots//" + DateUtils.getTimeStamp() + ".png");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
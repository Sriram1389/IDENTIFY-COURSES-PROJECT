package com.QEA22CSDQE007_Team3_IdentifyCourses.PageClasses;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.QEA22CSDQE007_Team3_IdentifyCourses.BaseClasses.PageBaseClass;
import com.QEA22CSDQE007_Team3_IdentifyCourses.BaseClasses.TopMenuClass;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class LandingPage extends PageBaseClass
{	
	public TopMenuClass topMenu;
	
	public LandingPage(WebDriver driver, ExtentTest logger)
	{
		super(driver, logger);
		
		topMenu = new TopMenuClass(driver, logger);
		PageFactory.initElements(driver, topMenu);
	}
	
	@FindBy(xpath="//input[@class='react-autosuggest__input']")
	public WebElement searchTextbox;
	
	@FindBy(xpath="//button[@class='nostyle search-button']/div")
	public WebElement searchButton;	
	
	@FindBy(xpath="//a[text()='For Campus']")
	public WebElement campus;
	
	JavascriptExecutor js = (JavascriptExecutor) driver;
	
	//Search course function
	public SearchPage doSearch(String search)
	{
		logger.log(Status.INFO, "Enter " + search + " in the Search textbox.");
		searchTextbox.sendKeys(search);
		logger.log(Status.PASS, "Entered " + search + " in the Search textbox successfully.");
		
		logger.log(Status.INFO, "Click on the Search button.");
		searchButton.click();
		logger.log(Status.PASS, "Clicked on the Search button successfully.");
		
		System.out.println(search + " searched successfully.\n");
		
		SearchPage searchPage = new SearchPage(driver, logger);
		PageFactory.initElements(driver, searchPage);
		return searchPage;
	}
	
	//Naviagate to Coursera for Campus page function
	public CampusPage navigateToCampus()
	{	
		waitElement(30, campus);
		js.executeScript("arguments[0].scrollIntoView();", campus);
		logger.log(Status.INFO, "Navigate to Coursera for Campus page.");
		campus.click();	
		logger.log(Status.PASS, "Navigated to Coursera for Campus page successfully.");
		System.out.println("Navigated to Coursera for Campus page successfully.\n");
		
		CampusPage campusPage = new CampusPage(driver, logger);
		PageFactory.initElements(driver, campusPage);
		return campusPage;
	}
	
	public TopMenuClass getTopMenu()
	{
		return topMenu;
	}
}
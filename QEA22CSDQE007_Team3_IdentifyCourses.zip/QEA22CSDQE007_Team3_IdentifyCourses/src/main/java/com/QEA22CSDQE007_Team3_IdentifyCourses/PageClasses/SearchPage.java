package com.QEA22CSDQE007_Team3_IdentifyCourses.PageClasses;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.QEA22CSDQE007_Team3_IdentifyCourses.BaseClasses.PageBaseClass;
import com.QEA22CSDQE007_Team3_IdentifyCourses.BaseClasses.TopMenuClass;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class SearchPage extends PageBaseClass
{	
	public TopMenuClass topMenu;
	
	public SearchPage(WebDriver driver, ExtentTest logger)
	{
		super(driver, logger);
		
		topMenu = new TopMenuClass(driver, logger);
		PageFactory.initElements(driver, topMenu);
	}
	
	@FindBy(xpath="//span[text()='Beginner']")
	public WebElement beginner;
		
	@FindBy(xpath="//button[contains(@aria-label, 'Show more Language options')]")
	public WebElement showMore;
	
	@FindBy(xpath="//span[contains(text(),'English')]")
	public WebElement english;
	
	@FindBy(xpath="//span[text()='Close']")
	public WebElement close;
	
	@FindBy(xpath="//a/div/div[2]/div/h2")
	public List<WebElement> names;
	
	@FindBy(xpath="//a/div/div[2]/div[2]/div/p[1]")
	public List<WebElement> ratings;
	
	@FindBy(xpath="//p[contains(text(),'Month') or contains(text(),'Weeks') or contains(text(),'Hours')]")
	public List<WebElement> totalLearningHours;
	
	@FindBy(xpath="//label[text()='Level']/parent::div/div/div/label/div/span")
	public List<WebElement> levels;
	
	@FindBy(xpath="//div[@aria-label='Select Language options']/div/label/div/span")
	public List<WebElement> languages;
	
	//Get Web Development Results function
	public void webDevelopmentResults()
	{
		logger = report.createTest("Display first two courses of Web Development for Beginner in English.");

		waitElement(30, beginner);
		logger.log(Status.INFO, "Select 'Beginner' level.");
		beginner.click();
		logger.log(Status.PASS, "'Beginner' level is selected successfully.");
		System.out.println("Beginner level is selected successfully.\n");
		

		waitElement(30, showMore);
		logger.log(Status.INFO, "Click on 'Show more' under 'Language' filter.");
		showMore.click();
		logger.log(Status.PASS, "Clicked on 'Show more' under 'Language' filter.");
		logger.log(Status.INFO, "Select 'English' language.");
		english.click();
		logger.log(Status.PASS, "'English' language is selected successfully.");
		logger.log(Status.INFO, "Click on 'Close'.");
		close.click();
		logger.log(Status.PASS, "Clicked on 'Close'.");		
		System.out.println("English language is selected successfully.\n");
		

		waitList(30, names);
		System.out.println("The first two Courses with their Total Learning Hours and Ratings are: \n");
		logger.log(Status.INFO, "The first two Courses with their Total Learning Hours and Ratings are:");
		for (int i = 0; i < 2; i++) 
		{
			System.out.println("Course Name : " + names.get(i).getText());
			logger.log(Status.PASS, "Course Name : " + names.get(i).getText());
			String duration = totalLearningHours.get(i).getText();
			String[] parts = duration.split(" · ");
			System.out.println("Total Learning Hours : " + parts[2]);
			logger.log(Status.PASS, "Total Learning Hours : " + parts[2]);
			System.out.println("Rating : " + ratings.get(i).getText());
			logger.log(Status.PASS, "Rating : " + ratings.get(i).getText());
			System.out.println("");
		}

		System.out.println("The first two Courses with their Total Learning Hours and Ratings are displayed successfully.\n");
		logger.log(Status.PASS, "The first two Courses with their Total Learning Hours and Ratings are displayed successfully.");
	}
	
	//Get Learning Language Results function
	public void learningLanguageResults()
	{
		logger = report.createTest("Extract all languages and different levels with its total count for Learning Language. ");
		
		waitList(30, levels);
		System.out.println("The Levels are: \n");
		logger.log(Status.INFO, "The Levels are:");

		for (int i = 0; i < levels.size(); i++) 
		{
			System.out.println(levels.get(i).getText());
			logger.log(Status.PASS, levels.get(i).getText());
		}
		System.out.println("\nTotal Levels count : " + levels.size());
		logger.log(Status.PASS, "Total Levels count : " + levels.size());
		
		System.out.println("\nAll Levels are extracted successfully.\n");
		logger.log(Status.PASS, "All Levels are extracted Successfully.");
		
		waitElement(30, showMore);
		logger.log(Status.INFO, "Click on 'Show more' under 'Language' filter.");
		showMore.click();
		logger.log(Status.PASS, "Clicked on 'Show more' under 'Language' filter.");
		waitList(30, languages);
		System.out.println("The Languages are: \n");
		logger.log(Status.INFO, "The Languages are:");
		for (int i = 0; i < languages.size(); i++) 
		{
			System.out.println(languages.get(i).getText());
			logger.log(Status.PASS, languages.get(i).getText());
		}		
		System.out.println("\nTotal Languages count : " + languages.size());
		logger.log(Status.PASS, "Total Languages count : " + languages.size());
		logger.log(Status.INFO, "Click on 'Close'.");
		close.click();
		logger.log(Status.PASS, "Clicked on 'Close'.");
		
		System.out.println("\nAll Languages are extracted successfully.\n");
		logger.log(Status.PASS, "All Languages are extracted successfully.");	
	}
	
	public TopMenuClass getTopMenu()
	{
		return topMenu;
	}
}
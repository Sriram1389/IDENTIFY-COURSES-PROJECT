package com.QEA22CSDQE007_Team3_IdentifyCourses.PageClasses;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.QEA22CSDQE007_Team3_IdentifyCourses.BaseClasses.PageBaseClass;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class CampusPage extends PageBaseClass
{
	public CampusPage(WebDriver driver, ExtentTest logger)
	{
		super(driver, logger);
	}
	
	@FindBy(xpath="//a[text()='Contact us']")
	public WebElement contact;
	
	@FindBy(id="FirstName")
	public WebElement fname;
	
	@FindBy(id="LastName")
	public WebElement lname;
	
	@FindBy(id="Title")
	public WebElement title;
	
	@FindBy(id="Email")
	public WebElement email;
	
	@FindBy(id="Phone")
	public WebElement phone;
	
	@FindBy(id="Company")
	public WebElement company;
	
	By institution = By.id("Institution_Type__c");
	
	By discipline = By.id("Primary_Discipline__c");
	
	By country = By.id("Country");
	
	By state = By.id("State");
	
	By description = By.id("What_the_lead_asked_for_on_the_website__c");
	
	@FindBy(xpath="//button[text()='Submit']")
	public WebElement submit;
	
	@FindBy(xpath="//div[@role='alert']")
	public WebElement alert;
	
	//Enter Details function
	public void enterDetails()
	{	
		logger = report.createTest("Display error when Email address is invalid.");

		waitElement(30, contact);
		logger.log(Status.INFO, "Click on 'Contact us'.");
		contact.click();
		logger.log(Status.PASS, "Clicked on 'Contact us'.");

		waitElement(30, fname);
		logger.log(Status.INFO, "Enter First Name in 'First Name' textbox.");
		fname.sendKeys("Vinay");
		logger.log(Status.PASS, "Entered First Name in 'First Name' textbox succesfully.");
		System.out.println("First Name is entered successfully.");

		waitElement(30, lname);
		logger.log(Status.INFO, "Enter Last Name in 'Last Name' textbox.");
		lname.sendKeys("Guduru");
		logger.log(Status.PASS, "Entered Last Name in 'Last Name' textbox succesfully.");
		System.out.println("Last Name is entered successfully.");

		waitElement(30, title);
		logger.log(Status.INFO, "Enter Job Title in 'Job Title' textbox.");
		title.sendKeys("CEO");
		logger.log(Status.PASS, "Entered Job Title in 'Job Title' textbox succesfully.");
		System.out.println("Job Title is entered successfully.");

		waitElement(30, email);
		logger.log(Status.INFO, "Enter Email in 'Work Email Address' textbox.");
		email.sendKeys("LM3Gaming.com");
		logger.log(Status.PASS, "Entered Email in 'Work Email Address' textbox succesfully.");
		System.out.println("Work Email Address is entered successfully.");

		waitElement(30, phone);
		logger.log(Status.INFO, "Enter Phone number in 'Phone Number' textbox.");
		phone.sendKeys("9876543210");
		logger.log(Status.PASS, "Entered Email in 'Work Email Address' textbox succesfully.");
		System.out.println("Phone Number is entered successfully.");

		waitElement(30, company);
		logger.log(Status.INFO, "Enter Institution name in 'Institution Name' textbox.");
		company.sendKeys("LM3Gaming");
		logger.log(Status.PASS, "Entered Institution name in 'Institution Name' textbox succesfully.");
		System.out.println("Institution Name is entered successfully.");

		wait(30, institution);
		Select institutionSelect = new Select(driver.findElement(institution));
		logger.log(Status.INFO, "Select Institution type from 'Institution Type' dropbox.");
		institutionSelect.selectByVisibleText("Private University");
		logger.log(Status.PASS, "Institution type is selected successfully.");
		System.out.println("Institution Type is selected successfully.");

		wait(30, discipline);
		Select disciplineSelect = new Select(driver.findElement(discipline));
		logger.log(Status.INFO, "Select Primary Discipline from 'Primary Discipline' dropbox.");
		disciplineSelect.selectByVisibleText("Entrepreneurship");
		logger.log(Status.PASS, "Primary Discipline is selected successfully.");
		System.out.println("Primary Discipline is selected successfully.");

		wait(30, country);
		Select countrySelect = new Select(driver.findElement(country));
		logger.log(Status.INFO, "Select Country from 'Country' dropbox.");
		countrySelect.selectByVisibleText("India");
		logger.log(Status.PASS, "Country is selected successfully.");
		System.out.println("Country is selected successfully.");

		wait(30, state);
		Select stateSelect = new Select(driver.findElement(state));
		logger.log(Status.INFO, "Select State from 'State' dropbox.");
		stateSelect.selectByVisibleText("Maharashtra");
		logger.log(Status.PASS, "State is selected successfully.");
		System.out.println("State is selected successfully.");

		wait(30, description);
		Select descriptionSelect = new Select(driver.findElement(description));
		logger.log(Status.INFO, "Select Description from 'Which best describes your needs:' dropbox.");
		descriptionSelect.selectByVisibleText("Meet with Coursera Sales Team");
		logger.log(Status.PASS, "Description is selected successfully.");
		System.out.println("Description is described successfully.");

		waitElement(30, submit);
		logger.log(Status.INFO, "Click on 'Submit' button.");
		submit.click();
		logger.log(Status.PASS, "Clicked on 'Submit' button.");

		System.out.println("\nData entered successfully.\n");
		logger.log(Status.PASS, "Data entered successfully.");

		if(alert == null)
		{
			reportPass("Data entered and submitted successfully.");
		}
		else
		{
			System.out.println("ERROR : " + alert.getText());
			reportFail(alert.getText());
		}
		
	}
}
package com.QEA22CSDQE007_Team3_IdentifyCourses.Utils;

import java.util.Date;

public class DateUtils 
{
	//Get Current Day_Month_Date function
	public static String getTimeStamp()
	{
		Date date = new Date();
		return date.toString().replaceAll(":", "_").replaceAll(" ", "_");
	}
}
package com.QEA22CSDQE007_Team3_IdentifyCourses.TestSuite;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.QEA22CSDQE007_Team3_IdentifyCourses.BaseClasses.BaseTestClass;
import com.QEA22CSDQE007_Team3_IdentifyCourses.BaseClasses.PageBaseClass;
import com.QEA22CSDQE007_Team3_IdentifyCourses.BaseClasses.TopMenuClass;
import com.QEA22CSDQE007_Team3_IdentifyCourses.PageClasses.CampusPage;
import com.QEA22CSDQE007_Team3_IdentifyCourses.PageClasses.LandingPage;
import com.QEA22CSDQE007_Team3_IdentifyCourses.PageClasses.SearchPage;

public class TestCases extends BaseTestClass
{
	LandingPage landingPage;
	TopMenuClass topMenu;
	SearchPage searchPage;
	CampusPage campusPage;
	
	@Test(priority = 1)
	@Parameters({"reportName", "search"})
	public void searchWebDevelopmentTest(String reportName, String search)
	{
		logger = report.createTest(reportName);
	
		invokeBrowser();
		
		PageBaseClass pageBase = new PageBaseClass(driver, logger);		
		PageFactory.initElements(driver, pageBase);
		
		landingPage = pageBase.openApplication();
		
		searchPage = landingPage.doSearch(search);
		
		searchPage.webDevelopmentResults();
		
		topMenu = searchPage.getTopMenu();
		
		topMenu.navigateToHome();
		
	}
	
	@Test(priority = 2)
	@Parameters({"reportName", "search"})
	public void searchLearningLanguageTest(String reportName, String search)
	{	
		logger = report.createTest(reportName);
		
		invokeBrowser();
		
		PageBaseClass pageBase = new PageBaseClass(driver, logger);		
		PageFactory.initElements(driver, pageBase);
		
		landingPage = pageBase.openApplication();
		
		searchPage = landingPage.doSearch(search);
		
		searchPage.learningLanguageResults();
		
		topMenu = searchPage.getTopMenu();
		
		topMenu.navigateToHome();
	}
	
	@Test(priority = 3)
	@Parameters("reportName")
	public void errorCaptureTest(String reportName)
	{	
		logger = report.createTest(reportName);
		
		invokeBrowser();
		
		PageBaseClass pageBase = new PageBaseClass(driver, logger);		
		PageFactory.initElements(driver, pageBase);
		
		landingPage = pageBase.openApplication();
		
		campusPage = landingPage.navigateToCampus();
		
		campusPage.enterDetails();
	}
}